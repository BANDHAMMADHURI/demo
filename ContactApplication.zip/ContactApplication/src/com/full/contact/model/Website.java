package com.full.contact.model;

public class Website {
	String webSite = " ";

	

	public String getWeb() {
		return webSite;
	}

	public void setWeb(String website) {
		this.webSite = website;
	}

	public String toString() {
		return webSite;
	}
}
