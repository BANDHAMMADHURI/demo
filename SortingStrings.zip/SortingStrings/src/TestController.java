import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;
import java.util.Scanner;
import java.util.Vector;

public class TestController {
	public static ArrayList<String> sorted(ArrayList<String> a2)

	{
		Collections.sort(a2);
		return a2;
	}

	public static LinkedList<String> sorted(LinkedList<String> l2)

	{
		Collections.sort(l2);
		return l2;
	}

	public static Vector<String> sorted(Vector<String> a2)

	{
		Collections.sort(a2);
		return a2;
	}

	public static void main(String args[]) {
		// sorting ArrayList elements
		ArrayList<String> b = new ArrayList<String>();

		b.add("Pineapple");
		b.add("Apple");
		b.add("Orange");
		b.add("Banana");
		ArrayList<String> a1 = TestController.sorted(b);
		System.out.println("The expected Arraylist is: [Apple, Banana,Orange, Pineaaple] and the result is : " + a1);

		// sorting LinkedList elements
		LinkedList<String> l = new LinkedList<String>();

		l.add("Pineapple");
		l.add("Apple");
		l.add("Orange");
		l.add("Banana");
		LinkedList<String> a2 = TestController.sorted(l);
		System.out.println("The expected Linkedlist is: [Apple, Banana,Orange, Pineaaple] and the result is : " + a2);

		// sorting Vector elements
		Vector<String> v = new Vector<String>();

		v.add("Pineapple");
		v.add("Apple");
		v.add("Orange");
		v.add("Banana");
		Vector<String> v2 = TestController.sorted(v);
		System.out.println("The expected Linkedlist is: [Apple, Banana,Orange, Pineaaple] and the result is : " + v2);

	}

}
