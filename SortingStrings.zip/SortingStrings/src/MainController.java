/*
 * Madhuri Bandham
 * 8 feb 2017
 * Sorting Strings using Collections Project*/
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;
import java.util.Scanner;
import java.util.Vector;

public class MainController {
	public static void main(String args[]) {
		ArrayList<String> a = new ArrayList<String>();
		LinkedList<String> l = new LinkedList<String>();
		Vector<String> v = new Vector<String>();
		Scanner scan = new Scanner(System.in);
		int i = 0;
		System.out.println("enter the number of names to be sort");
		int n = scan.nextInt();
		System.out.println("Please enter some names: ");

		while (i < n) {
			a.add(scan.next());
			i++;
		}
		l.addAll(a);
		v.addAll(a);

		System.out.println("The Sorted Arraylist is : ");
		ArrayList<String> a1 = TestController.sorted(a);
		System.out.println(a1);

		System.out.println("The Sorted Linkedlist is : ");
		LinkedList<String> l1 = TestController.sorted(l);
		System.out.println(l1);

		System.out.println("The Sorted Vector is : ");
		Vector<String> v1 = TestController.sorted(v);
		System.out.println(v1);

	}

}
