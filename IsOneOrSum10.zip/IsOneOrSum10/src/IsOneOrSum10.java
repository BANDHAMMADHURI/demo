
public class IsOneOrSum10 {
	public static boolean isOneOrSum10(int a, int b) {
		if (a == 10 || b == 10 || (a + b) == 10)
			return true;
		return false;
	}

	public static void main(String args[]) {
		System.out.println(IsOneOrSum10.isOneOrSum10(9, 9));
		System.out.println(IsOneOrSum10.isOneOrSum10(1, 9));
		System.out.println(IsOneOrSum10.isOneOrSum10(9, 10));

	}
}
