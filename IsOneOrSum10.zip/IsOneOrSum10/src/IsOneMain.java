
/*
 * Madhuri Bandham
 * 7 feb 2017
 * IsOneOrSum10 project
 */
import static java.lang.System.out;

import java.util.Scanner;

public class IsOneMain {

	public static void main(String args[]) {
		out.println("Welcome to IsOneOrSum10");
		out.println("Wanna Try(0/1)?");

		Scanner scan = new Scanner(System.in);
		int ans = scan.nextInt();

		if (ans == 1) {
			out.println("enter any integer");
			int i = scan.nextInt();
			out.println("enter another integer");
			int j = scan.nextInt();
			boolean result = IsOneOrSum10.isOneOrSum10(i, j);
			out.println("The result of the values : " + i + " and " + j + " is : " + result);
		} else
			out.println("Thank You...HAVE A NICE DAY :) ");
	}

}
